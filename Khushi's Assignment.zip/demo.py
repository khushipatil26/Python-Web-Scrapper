import time
import json
import csv
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options

# Initialize Selenium WebDriver
options = Options()
options.add_argument('--start-maximized')
options.add_argument('--disable-notifications')
options.add_argument('--disable-popup-blocking')

# Add your ChromeDriver path
service = Service("C:\\Users\\khush\\OneDrive\\Desktop\\placement\\python\\chromedriver.exe")
driver = webdriver.Chrome(service=service, options=options)

# Function to log in to Amazon
def amazon_login(email, password):
    driver.get('https://www.amazon.com/')
    
    # Click on Sign-In
    try:
        sign_in_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.ID, 'nav-link-accountList'))
        )
        sign_in_button.click()
    except Exception as e:
        print("Error clicking Sign-In button:", e)
        return

    # Enter email
    email_field = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, 'ap_email'))
    )
    email_field.send_keys(email)
    email_field.send_keys(Keys.RETURN)

    # Enter password
    password_field = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, 'ap_password'))
    )
    password_field.send_keys(password)
    password_field.send_keys(Keys.RETURN)

# Function to scrape best seller details
def scrape_best_sellers(categories):
    data = []

    for category in categories:
        print(f"Scraping category: {category}")
        driver.get(f"https://www.amazon.com/Best-Sellers/{category}")
        time.sleep(5)

        products = []

        for _ in range(30):  # Scroll to load more products, adjust as needed
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(2)

        items = driver.find_elements(By.CSS_SELECTOR, '.zg-item-immersion')

        for item in items[:1500]:
            try:
                product_name = item.find_element(By.CSS_SELECTOR, '.p13n-sc-truncate').text
                product_price = item.find_element(By.CSS_SELECTOR, '.p13n-sc-price').text
                sale_discount = "N/A"  # Placeholder if not directly available
                best_seller_rating = item.find_element(By.CSS_SELECTOR, '.a-icon-alt').get_attribute('innerHTML')
                ship_from = "N/A"  # Placeholder
                sold_by = "N/A"  # Placeholder
                rating = "N/A"  # Placeholder
                product_description = "N/A"  # Placeholder
                num_bought_last_month = "N/A"  # Placeholder
                category_name = category
                
                # Fetch product images
                images = item.find_elements(By.CSS_SELECTOR, 'img')
                image_urls = [img.get_attribute('src') for img in images]

                products.append({
                    'Product Name': product_name,
                    'Product Price': product_price,
                    'Sale Discount': sale_discount,
                    'Best Seller Rating': best_seller_rating,
                    'Ship From': ship_from,
                    'Sold By': sold_by,
                    'Rating': rating,
                    'Product Description': product_description,
                    'Number Bought in the Past Month': num_bought_last_month,
                    'Category Name': category_name,
                    'All Available Images': image_urls,
                })

            except Exception as e:
                print("Error scraping item details:", e)

        data.extend(products)

    return data

# Function to save data to CSV
def save_to_csv(data, filename):
    keys = data[0].keys()
    with open(filename, 'w', newline='', encoding='utf-8') as output_file:
        dict_writer = csv.DictWriter(output_file, fieldnames=keys)
        dict_writer.writeheader()
        dict_writer.writerows(data)

# Function to save data to JSON
def save_to_json(data, filename):
    with open(filename, 'w', encoding='utf-8') as json_file:
        json.dump(data, json_file, indent=4)

# Main Execution
if __name__ == "__main__":
    amazon_email = 'your_email@example.com'
    amazon_password = 'your_password'

    categories = [  # Example category URLs; replace with actual Amazon category paths
        'electronics', 'books', 'fashion', 'home', 'toys',
        'sports', 'beauty', 'health', 'automotive', 'garden'
    ]

    try:
        amazon_login(amazon_email, amazon_password)
        time.sleep(5)  # Wait for login

        scraped_data = scrape_best_sellers(categories)

        # Save data to files
        save_to_csv(scraped_data, 'amazon_best_sellers.csv')
        save_to_json(scraped_data, 'amazon_best_sellers.json')

        print("Scraping completed and data saved.")

    except Exception as e:
        print("An error occurred:", e)

    finally:
        driver.quit()

